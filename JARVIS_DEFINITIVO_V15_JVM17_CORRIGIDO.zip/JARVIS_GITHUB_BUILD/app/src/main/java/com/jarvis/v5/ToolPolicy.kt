package com.jarvis.v5

object ToolPolicy {
    private val allowed = setOf(
        "battery", "flashlight", "camera", "settings", "wifi", "bluetooth",
        "notifications", "sound", "location", "home", "search", "url", "app"
    )

    fun isAllowed(action: String): Boolean = action in allowed
    fun requiresConfirmation(call: AiToolCall): Boolean = call.confirmationRequired
}
