package com.jarvis.v5

object AiToolCallParser {
    fun parse(text: String): AiToolCall? {
        val line = text.trim().lineSequence()
            .firstOrNull { it.trim().startsWith("ACTION:", ignoreCase = true) }
            ?: return null

        val parts = line.split("|")
        val action = parts.firstOrNull { it.trim().startsWith("ACTION:", true) }
            ?.substringAfter(":")?.trim()?.lowercase() ?: return null

        if (!ToolPolicy.isAllowed(action)) return null

        val arg = parts.firstOrNull { it.trim().startsWith("ARG:", true) }
            ?.substringAfter(":")?.trim()?.ifBlank { null }

        val confirm = parts.firstOrNull { it.trim().startsWith("CONFIRM:", true) }
            ?.substringAfter(":")?.trim()?.equals("true", true) ?: false

        return AiToolCall(action, arg, confirm)
    }
}
