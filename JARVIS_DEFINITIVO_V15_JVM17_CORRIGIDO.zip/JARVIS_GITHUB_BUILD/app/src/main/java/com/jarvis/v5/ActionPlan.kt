package com.jarvis.v5

/**
 * Plano de ação seguro e explícito.
 * A IA futuramente poderá produzir esse formato; a execução continua
 * sob controle do aplicativo.
 */
data class ActionPlan(
    val action: String,
    val argument: String? = null,
    val requiresConfirmation: Boolean = false
)
