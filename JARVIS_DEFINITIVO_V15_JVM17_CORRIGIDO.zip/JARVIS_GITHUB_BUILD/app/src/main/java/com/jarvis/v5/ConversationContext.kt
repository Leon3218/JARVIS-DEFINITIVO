package com.jarvis.v5

object ConversationContext {
    fun build(memory: Memory, userMessage: String): AgentContext {
        return AgentContext(
            userMessage = userMessage,
            recentConversation = memory.recent(12),
            rememberedFacts = memory.facts().take(20)
        )
    }

    fun asPrompt(context: AgentContext): String {
        val history = if (context.recentConversation.isEmpty()) "(sem histórico)" 
            else context.recentConversation.joinToString("\n")
        val facts = if (context.rememberedFacts.isEmpty()) "(sem fatos lembrados)"
            else context.rememberedFacts.joinToString("\n- ", prefix = "- ")
        return """
CONTEXTO DO JARVIS
Histórico recente:
$history

Fatos lembrados:
$facts

Mensagem atual:
${context.userMessage}
""".trimIndent()
    }
}
