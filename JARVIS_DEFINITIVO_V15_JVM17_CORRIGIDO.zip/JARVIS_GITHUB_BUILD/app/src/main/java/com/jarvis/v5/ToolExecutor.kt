package com.jarvis.v5

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import java.util.Locale

class ToolExecutor(private val context: Context, private val tools: DeviceTools) {

    private val orchestrator = Orchestrator()

    fun execute(call: AiToolCall): String {
        if (!ToolPolicy.isAllowed(call.action)) {
            return "Essa ação não está autorizada pelo JARVIS."
        }
        if (ToolPolicy.requiresConfirmation(call)) {
            return "CONFIRM_REQUIRED:${call.action}"
        }
        return execute(ActionPlan(call.action, call.argument, false))
    }

    fun execute(raw: String): String? {
        val plan = orchestrator.plan(raw) ?: return null
        return execute(plan)
    }

    fun execute(plan: ActionPlan): String {
        return try {
            when (plan.action) {
                "battery" -> tools.battery()
                "flashlight" -> tools.flashlight(plan.argument == "on")
                "camera" -> tools.openCamera()
                "settings" -> tools.openSettings()
                "wifi" -> tools.openWifiSettings()
                "bluetooth" -> tools.openBluetoothSettings()
                "notifications" -> openSystem(Settings.ACTION_NOTIFICATION_SETTINGS, "notificações")
                "sound" -> openSystem(Settings.ACTION_SOUND_SETTINGS, "controles de som")
                "location" -> openSystem(Settings.ACTION_LOCATION_SOURCE_SETTINGS, "localização")
                "home" -> {
                    context.startActivity(
                        Intent(Intent.ACTION_MAIN)
                            .addCategory(Intent.CATEGORY_HOME)
                            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    )
                    "Abrindo a tela inicial."
                }
                "search" -> tools.openUrl(
                    "https://www.google.com/search?q=" + Uri.encode(plan.argument ?: "")
                )
                "url" -> {
                    var url = plan.argument?.trim().orEmpty()
                    if (!url.startsWith("http://") && !url.startsWith("https://")) {
                        url = "https://$url"
                    }
                    tools.openUrl(url)
                }
                "app" -> {
                    val target = plan.argument?.trim().orEmpty()
                    val result = tools.openInstalledAppByName(target)
                    result ?: "Não encontrei o aplicativo \"$target\"."
                }
                else -> "Ação não autorizada pelo núcleo do JARVIS."
            }
        } catch (e: SecurityException) {
            "O Android bloqueou esta ação por falta de permissão."
        } catch (e: Exception) {
            "Não consegui executar a ação: ${e.message ?: "erro desconhecido"}."
        }
    }

    private fun openSystem(action: String, label: String): String {
        return try {
            val i = Intent(action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            if (i.resolveActivity(context.packageManager) != null) {
                context.startActivity(i)
                "Abrindo $label."
            } else {
                "O Android deste aparelho não disponibilizou essa tela."
            }
        } catch (_: Exception) {
            "Não consegui abrir $label."
        }
    }
}
