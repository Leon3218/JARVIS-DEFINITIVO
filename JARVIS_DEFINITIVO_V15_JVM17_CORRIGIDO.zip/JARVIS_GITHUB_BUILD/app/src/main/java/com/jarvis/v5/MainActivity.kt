package com.jarvis.v5

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.widget.*
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var memory: Memory
    private lateinit var secrets: SecretStore
    private lateinit var ai: AIClient
    private lateinit var tools: DeviceTools
    private lateinit var executor: ToolExecutor
    private lateinit var agent: JarvisAgent
    private lateinit var conversationMode: ConversationMode
    private lateinit var voiceLoop: VoiceLoopController
    private lateinit var tts: TextToSpeech
    private lateinit var log: TextView
    private lateinit var input: EditText
    private lateinit var time: TextView
    private lateinit var status: TextView
    private lateinit var coreState: TextView
    private lateinit var voiceState: TextView
    private lateinit var aiState: TextView
    private var speech: SpeechRecognizer? = null
    private val handler = Handler(Looper.getMainLooper())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        memory = Memory(this)
        secrets = SecretStore(this)
        ai = AIClient(secrets)
        tools = DeviceTools(this)
        executor = ToolExecutor(this, tools)
        agent = JarvisAgent(memory, Orchestrator(), executor)
        conversationMode = ConversationMode()
        voiceLoop = VoiceLoopController(conversationMode)

        tts = TextToSpeech(this, this)
        tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {}
            override fun onDone(utteranceId: String?) {
                if (utteranceId == "jarvis") runOnUiThread {
                    if (continueListeningIfEnabled()) handler.postDelayed({ startVoiceInternal() }, 350)
                }
            }
            override fun onError(utteranceId: String?) {
                if (utteranceId == "jarvis") runOnUiThread {
                    if (continueListeningIfEnabled()) handler.postDelayed({ startVoiceInternal() }, 500)
                }
            }
        })

        bind()
        requestPermissionsIfNeeded()
        tick()
        updateStates()
        respond("JARVIS online. Núcleo definitivo inicializado. Diga 'ajuda' para conhecer os comandos.", true, false)
    }

    private fun bind() {
        log = findViewById(R.id.log)
        input = findViewById(R.id.input)
        time = findViewById(R.id.time)
        status = findViewById(R.id.status)
        coreState = findViewById(R.id.coreState)
        voiceState = findViewById(R.id.voiceState)
        aiState = findViewById(R.id.aiState)

        findViewById<Button>(R.id.send).setOnClickListener { send(input.text.toString()) }
        findViewById<Button>(R.id.voice).setOnClickListener { startVoice() }
        findViewById<Button>(R.id.apps).setOnClickListener { openApps() }
        findViewById<Button>(R.id.settings).setOnClickListener { openSettings() }
        findViewById<Button>(R.id.network).setOnClickListener { respond(networkSummary()) }
        findViewById<Button>(R.id.memoryButton).setOnClickListener { showMemory() }
        findViewById<Button>(R.id.aiButton).setOnClickListener { configureAI() }
        findViewById<Button>(R.id.toolsButton).setOnClickListener { showTools() }
        findViewById<Button>(R.id.deviceButton).setOnClickListener { showDevice() }
        findViewById<Button>(R.id.clearButton).setOnClickListener { log.text = "Console limpa. Núcleo preservado." }
    }

    private fun send(text: String) {
        if (text.isBlank()) return
        input.setText("")
        log.append("\n\nVOCÊ: $text")
        val agentResult = agent.handle(text)
        if (agentResult.executed || agentResult.text.isNotBlank()) {
            respond(agentResult.text)
            updateStates()
            return
        }

        memory.add("user", text)
        val local = localCommand(text)
        if (local != null) {
            respond(local)
            updateStates()
            return
        }

        val action = executor.execute(text)
        if (action != null) {
            respond(action)
            updateStates()
            return
        }

        status.text = "● JARVIS • PROCESSANDO"
        ai.ask(ConversationContext.asPrompt(agent.contextFor(text)), memory.recent()) { answer ->
            runOnUiThread {
                val call = AiToolCallParser.parse(answer)
                if (call != null) {
                    if (call.confirmationRequired) {
                        askConfirmation(call)
                    } else {
                        val result = executor.execute(call)
                        respond(result)
                    }
                } else {
                    respond(answer)
                }
                updateStates()
            }
        }
    }

    private fun askConfirmation(call: AiToolCall) {
        AlertDialog.Builder(this)
            .setTitle("CONFIRMAÇÃO JARVIS")
            .setMessage("A IA solicitou a ação: ${call.action}" +
                (call.argument?.let { "\nAlvo: $it" } ?: "") +
                "\n\nDeseja executar?")
            .setPositiveButton("EXECUTAR") { _, _ ->
                respond(executor.execute(ActionPlan(call.action, call.argument, false)))
                updateStates()
            }
            .setNegativeButton("CANCELAR") { _, _ -> respond("Ação cancelada.", speak = false) }
            .show()
    }

    private fun localCommand(raw: String): String? {
        val t = raw.trim().lowercase(Locale.getDefault())
        return when {
            t == "configurar ia" || t == "configurar inteligência artificial" -> {
                configureAI(); "Abrindo configuração do cérebro de IA."
            }
            t == "status" || t == "diagnóstico" || t == "diagnostico" -> aiStatus()
            t == "modo conversa" || t == "conversa contínua" || t == "conversa continua" -> {
                if (!voiceLoop.isEnabled()) { voiceLoop.start(); startVoiceInternal() }
                "Modo conversa contínua ativado."
            }
            t == "parar conversa" || t == "encerrar conversa" -> {
                stopVoice(); "Modo conversa contínua desativado."
            }
            t == "cérebro" || t == "cerebro" ->
                "Cérebro JARVIS ativo: memória, orquestrador, ferramentas locais, voz e IA configurável."
            t == "ajuda" || t == "comandos" -> helpText()
            t.contains("bateria") -> tools.battery()
            t.contains("lanterna") && (t.contains("liga") || t.contains("acende")) -> tools.flashlight(true)
            t.contains("lanterna") && (t.contains("desliga") || t.contains("apaga")) -> tools.flashlight(false)
            t == "hora" || t.contains("que horas") ->
                "Agora são ${SimpleDateFormat("HH:mm", Locale("pt", "BR")).format(Date())}."
            t == "data" || t.contains("que dia") ->
                "Hoje é ${SimpleDateFormat("EEEE, dd 'de' MMMM 'de' yyyy", Locale("pt", "BR")).format(Date())}."
            t.contains("abrir configurações") || t == "configurações" || t == "configuracoes" -> tools.openSettings()
            t.contains("abrir wi-fi") || t.contains("abrir wifi") -> tools.openWifiSettings()
            t.contains("abrir bluetooth") -> tools.openBluetoothSettings()
            t.contains("abrir câmera") || t.contains("abrir camera") -> tools.openCamera()
            t.startsWith("pesquisar ") -> tools.openUrl("https://www.google.com/search?q=" + UriCodec.encode(raw.substringAfter(" ")))
            t.startsWith("lembrar que") -> {
                val value = raw.substringAfter("lembrar que", "", true).trim()
                if (value.isBlank()) "Diga o que devo lembrar."
                else { memory.rememberFact(value); "Memória registrada." }
            }
            t == "minha memória" || t == "minhas memórias" -> {
                val facts = memory.facts()
                if (facts.isEmpty()) "Não há memórias registradas."
                else "Memórias:\n" + facts.take(20).joinToString("\n• ", prefix = "• ")
            }
            t.contains("abrir whatsapp") -> tools.openApp("com.whatsapp", "WhatsApp")
            t.contains("abrir youtube") -> tools.openApp("com.google.android.youtube", "YouTube")
            t.contains("abrir spotify") -> tools.openApp("com.spotify.music", "Spotify")
            t.contains("abrir instagram") -> tools.openApp("com.instagram.android", "Instagram")
            t.contains("abrir telegram") -> tools.openApp("org.telegram.messenger", "Telegram")
            t.contains("abrir chrome") -> tools.openApp("com.android.chrome", "Chrome")
            else -> null
        }
    }

    private fun helpText() = """
        COMANDOS JARVIS
        • hora / data / bateria
        • lanterna ligada / desligada
        • abrir câmera / configurações / Wi-Fi / Bluetooth
        • abrir WhatsApp / YouTube / Spotify / Instagram / Telegram / Chrome
        • abrir <nome do aplicativo>
        • pesquisar <texto>
        • abrir site <endereço>
        • lembrar que <informação>
        • minha memória
        • rede / diagnóstico / status
        • configurar IA
        • modo conversa / parar conversa
        • aplicativos / ferramentas / dispositivo
    """.trimIndent()

    private fun respond(text: String, speak: Boolean = true, save: Boolean = true) {
        log.append("\nJARVIS: $text")
        status.text = "● SISTEMA • ATIVO"
        if (save) memory.add("assistant", text)
        if (speak) say(text)
    }

    private fun say(text: String) {
        if (::tts.isInitialized) {
            tts.speak(text.take(3500), TextToSpeech.QUEUE_FLUSH, null, "jarvis")
        }
    }

    private fun startVoice() {
        if (voiceLoop.isEnabled()) {
            stopVoice()
            return
        }
        voiceLoop.start()
        startVoiceInternal()
        updateStates()
    }

    private fun stopVoice() {
        voiceLoop.stop()
        speech?.cancel()
        speech?.destroy()
        speech = null
        status.text = "● SISTEMA • ATIVO"
        updateStates()
    }

    private fun startVoiceInternal() {
        if (!voiceLoop.isEnabled()) return
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO), 10)
            return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            voiceLoop.stop()
            respond("Reconhecimento de voz indisponível neste aparelho.")
            return
        }

        speech?.destroy()
        speech = SpeechRecognizer.createSpeechRecognizer(this)
        speech!!.setRecognitionListener(object : android.speech.RecognitionListener {
            override fun onReadyForSpeech(p0: Bundle?) { status.text = "● JARVIS • OUVINDO" }
            override fun onBeginningOfSpeech() { status.text = "● JARVIS • CAPTANDO" }
            override fun onResults(b: Bundle) {
                val heard = b.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()?.trim()
                if (heard.isNullOrBlank()) {
                    if (continueListeningIfEnabled()) handler.postDelayed({ startVoiceInternal() }, 300)
                } else send(heard)
            }
            override fun onError(e: Int) {
                if (continueListeningIfEnabled()) handler.postDelayed({ startVoiceInternal() }, 500)
                else status.text = "● SISTEMA • ATIVO"
            }
            override fun onRmsChanged(v: Float) {}
            override fun onBufferReceived(b: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onPartialResults(b: Bundle?) {}
            override fun onEvent(a: Int, b: Bundle?) {}
        })
        speech!!.startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "pt-BR")
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Fale com o JARVIS")
        })
        updateStates()
    }

    private fun openApps() {
        val apps = tools.apps()
        if (apps.isEmpty()) { respond("Não encontrei aplicativos iniciáveis."); return }
        AlertDialog.Builder(this).setTitle("CENTRAL DE APLICATIVOS")
            .setItems(apps.map { it.first }.toTypedArray()) { _, which -> startActivity(apps[which].second) }
            .show()
    }

    private fun showMemory() {
        val facts = memory.facts()
        val recent = memory.recent(12)
        val text = buildString {
            append("MEMÓRIA PERMANENTE\n\n")
            append(if (facts.isEmpty()) "Nenhum fato salvo.\n" else facts.joinToString("\n• ", prefix = "• ") + "\n")
            append("\nCONVERSA RECENTE\n\n")
            append(if (recent.isEmpty()) "Nenhuma conversa registrada." else recent.joinToString("\n"))
        }
        AlertDialog.Builder(this).setTitle("MEMÓRIA JARVIS").setMessage(text)
            .setPositiveButton("OK", null).show()
    }

    private fun showTools() {
        AlertDialog.Builder(this).setTitle("FERRAMENTAS DO NÚCLEO")
            .setItems(arrayOf(
                "Bateria", "Lanterna", "Câmera", "Wi-Fi", "Bluetooth",
                "Notificações", "Som", "Localização", "Pesquisar", "Aplicativos"
            )) { _, which ->
                when (which) {
                    0 -> respond(tools.battery())
                    1 -> respond(tools.flashlight(true))
                    2 -> respond(tools.openCamera())
                    3 -> respond(tools.openWifiSettings())
                    4 -> respond(tools.openBluetoothSettings())
                    5 -> respond(executor.execute(ActionPlan("notifications")))
                    6 -> respond(executor.execute(ActionPlan("sound")))
                    7 -> respond(executor.execute(ActionPlan("location")))
                    8 -> respond("Use: pesquisar <texto>")
                    9 -> openApps()
                }
            }.show()
    }

    private fun showDevice() {
        val pm = packageManager
        val apps = tools.apps().size
        val androidVersion = android.os.Build.VERSION.RELEASE
        val sdk = android.os.Build.VERSION.SDK_INT
        val model = "${android.os.Build.MANUFACTURER} ${android.os.Build.MODEL}"
        AlertDialog.Builder(this).setTitle("DIAGNÓSTICO DO DISPOSITIVO")
            .setMessage("Modelo: $model\nAndroid: $androidVersion (API $sdk)\nApps iniciáveis: $apps\n\n${networkSummary()}\n\n${tools.battery()}")
            .setPositiveButton("OK", null).show()
    }

    private fun aiStatus(): String {
        val provider = secrets.get("provider") ?: "nenhum"
        val model = secrets.get("model") ?: "não configurado"
        val key = if (secrets.get("api_key").isNullOrBlank()) "ausente" else "configurada"
        return "Núcleo JARVIS\nIA: $provider\nModelo: $model\nChave: $key\nMemória: ativa\nVoz: ${if (SpeechRecognizer.isRecognitionAvailable(this)) "disponível" else "indisponível"}."
    }

    private fun configureAI() {
        val layout = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(48, 16, 48, 8) }
        val provider = EditText(this).apply { hint = "openai / gemini / anthropic"; setText(secrets.get("provider") ?: "") }
        val model = EditText(this).apply { hint = "Modelo exato do provedor"; setText(secrets.get("model") ?: "") }
        val endpoint = EditText(this).apply { hint = "Endpoint (opcional para OpenAI/compatível)"; setText(secrets.get("endpoint") ?: "") }
        val key = EditText(this).apply {
            hint = "Chave da API"
            inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD
            setText(secrets.get("api_key") ?: "")
        }
        layout.addView(provider); layout.addView(model); layout.addView(endpoint); layout.addView(key)
        AlertDialog.Builder(this).setTitle("CÉREBRO DE IA")
            .setMessage("As credenciais ficam protegidas localmente pelo Android Keystore. Nunca coloque uma chave no GitHub.")
            .setView(layout)
            .setPositiveButton("SALVAR") { _, _ ->
                secrets.put("provider", provider.text.toString().trim().lowercase(Locale.getDefault()))
                secrets.put("model", model.text.toString().trim())
                secrets.put("endpoint", endpoint.text.toString().trim())
                secrets.put("api_key", key.text.toString().trim())
                respond("Configuração do cérebro atualizada.")
                updateStates()
            }.setNegativeButton("CANCELAR", null).show()
    }

    private fun openSettings() { respond(tools.openSettings(), false) }

    private fun networkSummary(): String {
        val cm = getSystemService(CONNECTIVITY_SERVICE) as android.net.ConnectivityManager
        val n = cm.activeNetwork
        val c = cm.getNetworkCapabilities(n)
        val type = when {
            c?.hasTransport(android.net.NetworkCapabilities.TRANSPORT_WIFI) == true -> "Wi-Fi"
            c?.hasTransport(android.net.NetworkCapabilities.TRANSPORT_CELLULAR) == true -> "rede móvel"
            else -> "sem conexão"
        }
        return "Conectividade: $type\nInterface ativa detectada pelo Android."
    }

    private fun tick() {
        time.text = SimpleDateFormat("HH:mm", Locale("pt", "BR")).format(Date())
        handler.postDelayed({ tick() }, 1000)
    }

    private fun updateStates() {
        if (!::coreState.isInitialized) return
        coreState.text = "NÚCLEO\nONLINE"
        voiceState.text = if (voiceLoop.isEnabled()) "VOZ\nOUVINDO" else "VOZ\nPRONTA"
        aiState.text = if (secrets.get("api_key").isNullOrBlank()) "IA\nLOCAL" else "IA\nONLINE"
    }

    private fun requestPermissionsIfNeeded() {
        val p = mutableListOf<String>()
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) p += Manifest.permission.RECORD_AUDIO
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) p += Manifest.permission.CAMERA
        if (p.isNotEmpty()) ActivityCompat.requestPermissions(this, p.toTypedArray(), 10)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<String>, results: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, results)
        if (requestCode == 10 && voiceLoop.isEnabled() &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            startVoiceInternal()
        }
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) tts.language = Locale("pt", "BR")
    }

    override fun onDestroy() {
        if (::conversationMode.isInitialized) conversationMode.stop()
        speech?.destroy()
        tts.stop()
        tts.shutdown()
        handler.removeCallbacksAndMessages(null)
        super.onDestroy()
    }

    private fun continueListeningIfEnabled() =
        ::voiceLoop.isInitialized && voiceLoop.shouldListenAgain()
}

private object UriCodec {
    fun encode(value: String): String = java.net.URLEncoder.encode(value, "UTF-8")
}
