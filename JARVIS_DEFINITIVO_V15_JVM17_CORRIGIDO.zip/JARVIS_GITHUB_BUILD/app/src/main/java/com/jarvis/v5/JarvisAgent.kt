package com.jarvis.v5

class JarvisAgent(
    private val memory: Memory,
    private val orchestrator: Orchestrator,
    private val executor: ToolExecutor
) {
    data class Result(val text: String, val executed: Boolean = false)

    fun handle(message: String): Result {
        val plan = orchestrator.plan(message)
        if (plan != null) {
            val result = executor.execute(plan)
            memory.add("user", message)
            memory.add("assistant", result)
            return Result(result, executed = true)
        }

        val lower = message.trim().lowercase()
        if (lower.startsWith("lembrar que ")) {
            val fact = message.substringAfter("lembrar que ").trim()
            if (fact.isNotBlank()) {
                memory.rememberFact(fact)
                val answer = "Entendido. Vou guardar isso na memória do JARVIS."
                memory.add("user", message)
                memory.add("assistant", answer)
                return Result(answer)
            }
        }

        if (lower == "minha memória" || lower == "minha memoria") {
            val facts = memory.facts()
            val answer = if (facts.isEmpty()) "Minha memória permanente ainda está vazia."
                else "Na minha memória: " + facts.joinToString("; ")
            memory.add("user", message)
            memory.add("assistant", answer)
            return Result(answer)
        }

        return Result("")
    }
    fun handleAiResponse(response: String, parser: (String) -> AiToolCall?): Result {
        val call = parser(response) ?: return Result(response)
        val result = executor.execute(call)
        if (result.startsWith("CONFIRM_REQUIRED:")) {
            return Result("Preciso da sua confirmação antes de executar essa ação.")
        }
        memory.add("assistant", result)
        return Result(result, executed = true)
    }

    fun contextFor(message: String): AgentContext =
        ConversationContext.build(memory, message)

}
