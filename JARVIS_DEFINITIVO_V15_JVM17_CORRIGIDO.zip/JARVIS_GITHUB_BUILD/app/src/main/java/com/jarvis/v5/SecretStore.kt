package com.jarvis.v5

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.spec.GCMParameterSpec

class SecretStore(private val context: Context) {
    private val prefs = context.getSharedPreferences("jarvis_secrets", Context.MODE_PRIVATE)
    private val alias = "jarvis_master_key"
    private fun key(): java.security.Key {
        val ks=KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        if(!ks.containsAlias(alias)) { val kg=KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES,"AndroidKeyStore"); kg.init(KeyGenParameterSpec.Builder(alias,KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT).setBlockModes(KeyProperties.BLOCK_MODE_GCM).setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE).build()); kg.generateKey() }
        return ks.getKey(alias,null)
    }
    fun put(name:String,value:String) { val c=Cipher.getInstance("AES/GCM/NoPadding"); c.init(Cipher.ENCRYPT_MODE,key()); val data=c.iv+c.doFinal(value.toByteArray()); prefs.edit().putString(name,Base64.encodeToString(data,Base64.NO_WRAP)).apply() }
    fun get(name:String):String? = prefs.getString(name,null)?.let { raw -> try { val b=Base64.decode(raw,Base64.NO_WRAP); val c=Cipher.getInstance("AES/GCM/NoPadding"); c.init(Cipher.DECRYPT_MODE,key(),GCMParameterSpec(128,b.copyOfRange(0,12))); String(c.doFinal(b.copyOfRange(12,b.size))) } catch(_:Exception){null} }
}
