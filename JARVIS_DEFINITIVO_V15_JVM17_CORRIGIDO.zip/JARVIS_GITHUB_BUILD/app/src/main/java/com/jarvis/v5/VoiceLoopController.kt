package com.jarvis.v5

/**
 * Controlador de alto nível do ciclo de voz.
 *
 * O componente não inicia o microfone por conta própria: a Activity decide
 * quando pedir a permissão e iniciar o SpeechRecognizer. Depois da resposta,
 * ela pode chamar `shouldListenAgain()` e iniciar uma nova captura.
 */
class VoiceLoopController(private val mode: ConversationMode) {

    fun start(): String = mode.start()
    fun stop(): String = mode.stop()
    fun isEnabled(): Boolean = mode.enabled

    fun shouldListenAgain(): Boolean = mode.enabled
}
