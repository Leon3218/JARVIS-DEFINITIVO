package com.jarvis.v5

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class Memory(context: Context) : SQLiteOpenHelper(context, "jarvis_memory.db", null, 1) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE IF NOT EXISTS messages(id INTEGER PRIMARY KEY AUTOINCREMENT, role TEXT, text TEXT, created INTEGER)")
        db.execSQL("CREATE TABLE IF NOT EXISTS facts(key TEXT PRIMARY KEY, value TEXT, updated INTEGER)")
    }
    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {}

    fun add(role: String, text: String) {
        writableDatabase.execSQL(
            "INSERT INTO messages(role,text,created) VALUES(?,?,strftime('%s','now'))",
            arrayOf(role, text)
        )
    }

    fun recent(limit: Int = 20): List<String> {
        val out = mutableListOf<String>()
        val c = readableDatabase.rawQuery(
            "SELECT role || ': ' || text FROM messages ORDER BY id DESC LIMIT ?",
            arrayOf(limit.toString())
        )
        c.use { while (it.moveToNext()) out.add(it.getString(0)) }
        out.reverse()
        return out
    }

    fun rememberFact(value: String) {
        writableDatabase.execSQL(
            "INSERT OR REPLACE INTO facts(key,value,updated) VALUES(?,?,strftime('%s','now'))",
            arrayOf("fact_" + value.hashCode(), value)
        )
    }

    fun facts(): List<String> {
        val out = mutableListOf<String>()
        val c = readableDatabase.rawQuery("SELECT value FROM facts ORDER BY updated DESC LIMIT 50", null)
        c.use { while (it.moveToNext()) out.add(it.getString(0)) }
        return out
    }
}
