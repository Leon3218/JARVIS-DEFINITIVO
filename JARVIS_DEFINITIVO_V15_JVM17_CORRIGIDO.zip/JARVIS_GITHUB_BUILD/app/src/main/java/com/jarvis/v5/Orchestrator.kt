package com.jarvis.v5

import java.util.Locale

/**
 * Orquestrador local: converte linguagem natural em um plano de ação.
 * Ele não concede à IA acesso arbitrário ao Android.
 */
class Orchestrator {

    fun plan(text: String): ActionPlan? {
        val raw = text.trim()
        val t = raw.lowercase(Locale.getDefault())

        return when {
            t == "bateria" || t.contains("status da bateria") ->
                ActionPlan("battery")

            t.contains("ligar") && t.contains("lanterna") ->
                ActionPlan("flashlight", "on")

            t.contains("acender") && t.contains("lanterna") ->
                ActionPlan("flashlight", "on")

            t.contains("desligar") && t.contains("lanterna") ->
                ActionPlan("flashlight", "off")

            t.contains("apagar") && t.contains("lanterna") ->
                ActionPlan("flashlight", "off")

            t.contains("abrir câmera") || t.contains("abrir camera") ->
                ActionPlan("camera")

            t.contains("abrir configurações") || t == "configurações" || t == "configuracoes" ->
                ActionPlan("settings")

            t.contains("abrir wi-fi") || t.contains("abrir wifi") ->
                ActionPlan("wifi")

            t.contains("abrir bluetooth") ->
                ActionPlan("bluetooth")

            t.contains("notificações") || t.contains("notificacoes") ->
                ActionPlan("notifications")

            t.contains("volume") || t.contains("configurações de som") ->
                ActionPlan("sound")

            t.contains("localização") || t.contains("localizacao") ->
                ActionPlan("location")

            t == "modo launcher" || t.contains("ativar modo launcher") ->
                ActionPlan("home")

            t.startsWith("pesquisar ") ->
                ActionPlan("search", raw.substringAfter(" ").trim())

            t.startsWith("abrir site ") ->
                ActionPlan("url", raw.substringAfter(" ").trim())

            t.startsWith("abrir ") ->
                ActionPlan("app", raw.substringAfter(" ").trim())

            else -> null
        }
    }
}
