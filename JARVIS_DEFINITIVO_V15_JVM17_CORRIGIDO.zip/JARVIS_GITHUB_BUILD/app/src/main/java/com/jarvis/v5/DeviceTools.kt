package com.jarvis.v5

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.camera2.CameraManager
import android.net.Uri
import android.os.BatteryManager
import android.provider.Settings
import java.util.Locale

class DeviceTools(private val context: Context) {
    fun battery(): String {
        val bm = context.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
        val level = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
        val charging = bm.isCharging
        return "Bateria: $level%\nEstado: ${if (charging) "carregando" else "em uso"}"
    }

    fun flashlight(on: Boolean): String {
        return try {
            val camera = context.getSystemService(Context.CAMERA_SERVICE) as CameraManager
            val id = camera.cameraIdList.firstOrNull { camera.getCameraCharacteristics(it).get(android.hardware.camera2.CameraCharacteristics.FLASH_INFO_AVAILABLE) == true }
                ?: return "Este aparelho não informou uma câmera com flash."
            camera.setTorchMode(id, on)
            if (on) "Lanterna ligada." else "Lanterna desligada."
        } catch (e: SecurityException) {
            "Preciso da permissão da câmera para controlar a lanterna."
        } catch (e: Exception) {
            "Não consegui controlar a lanterna: ${e.message ?: "erro"}."
        }
    }

    fun openSettings(): String {
        context.startActivity(Intent(Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        return "Abrindo configurações do Android."
    }

    fun openWifiSettings(): String {
        context.startActivity(Intent(Settings.ACTION_WIFI_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        return "Abrindo configurações de Wi-Fi."
    }

    fun openBluetoothSettings(): String {
        context.startActivity(Intent(Settings.ACTION_BLUETOOTH_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        return "Abrindo configurações de Bluetooth."
    }

    fun openCamera(): String {
        val intent = Intent("android.media.action.IMAGE_CAPTURE").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return if (intent.resolveActivity(context.packageManager) != null) {
            context.startActivity(intent); "Abrindo câmera."
        } else "Câmera indisponível."
    }

    fun openUrl(url: String): String {
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return if (intent.resolveActivity(context.packageManager) != null) {
            context.startActivity(intent); "Abrindo navegador."
        } else "Não encontrei um navegador compatível."
    }

    fun openApp(packageName: String, label: String): String {
        val intent = context.packageManager.getLaunchIntentForPackage(packageName)?.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            ?: return "$label não está instalado."
        context.startActivity(intent)
        return "Abrindo $label."
    }

    fun apps(): List<Pair<String, Intent>> {
        val pm = context.packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return pm.queryIntentActivities(intent, PackageManager.MATCH_ALL)
            .map { it.loadLabel(pm).toString() to (Intent(intent).setClassName(it.activityInfo.packageName, it.activityInfo.name).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
            .distinctBy { it.first }
            .sortedBy { it.first.lowercase() }
    }
    fun openInstalledAppByName(query: String): String? {
        val wanted = query.trim().lowercase(Locale.getDefault())
        if (wanted.isBlank()) return null
        val candidates = apps()
        val match = candidates.firstOrNull { it.first.lowercase(Locale.getDefault()) == wanted }
            ?: candidates.firstOrNull { it.first.lowercase(Locale.getDefault()).contains(wanted) }
        return if (match != null) {
            context.startActivity(match.second)
            "Abrindo ${match.first}."
        } else null
    }

}
