package com.jarvis.v5

/**
 * Estado do modo de conversa.
 * O modo contínuo só fica ativo quando o usuário o habilita.
 */
class ConversationMode {
    var enabled: Boolean = false
        private set

    fun start(): String {
        enabled = true
        return "Modo conversa contínua ativado. Pode falar."
    }

    fun stop(): String {
        enabled = false
        return "Modo conversa contínua desativado."
    }

    fun toggle(): String {
        return if (enabled) stop() else start()
    }
}
