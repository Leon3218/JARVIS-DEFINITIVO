package com.jarvis.v5

data class AgentContext(
    val userMessage: String,
    val recentConversation: List<String>,
    val rememberedFacts: List<String>
)
