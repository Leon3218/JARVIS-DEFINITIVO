package com.jarvis.v5

data class AiToolCall(
    val action: String,
    val argument: String? = null,
    val confirmationRequired: Boolean = false
)
