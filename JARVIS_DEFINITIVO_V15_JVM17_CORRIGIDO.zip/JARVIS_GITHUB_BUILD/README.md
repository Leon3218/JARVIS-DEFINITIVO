# JARVIS V6 — DEFINITIVO

Base nativa Android/Kotlin do JARVIS.

## O que está integrado

- Launcher/Home Android.
- Interface HUD/Central JARVIS.
- Conversa por texto.
- Voz contínua em pt-BR.
- TTS em pt-BR.
- Memória SQLite de conversa e fatos.
- Cérebro de IA configurável.
- Provedores configuráveis: OpenAI, Gemini e Anthropic.
- Chaves armazenadas localmente com Android Keystore.
- Orquestrador de comandos.
- Ferramentas Android com allowlist.
- Execução de ferramentas solicitadas pela IA.
- Confirmação para tool calls marcadas como sensíveis.
- Bateria, lanterna, câmera, Wi-Fi, Bluetooth, som, notificações e localização.
- Pesquisa web e abertura de sites.
- Abertura de aplicativos instalados.
- Diagnóstico de dispositivo e rede.
- Central de aplicativos.
- Workflow GitHub Actions para gerar APK.

## Segurança

As chaves de IA NÃO ficam no código. Configure-as dentro do aplicativo.
O APK debug gerado pelo GitHub é o artefato de teste instalável.

Para publicação na Play Store, será necessário assinar uma versão release
com um keystore privado guardado como GitHub Secret. O keystore nunca deve
ser colocado no repositório.

## Fluxo de build

GitHub → Actions → JARVIS Definitivo — Build APK → Run workflow → artefato
`JARVIS-Definitivo-APK-Instalavel`.
