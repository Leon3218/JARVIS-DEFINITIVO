#!/usr/bin/env bash
set -euo pipefail
gradle --no-daemon :app:assembleDebug :app:assembleRelease
echo "DEBUG: app/build/outputs/apk/debug/app-debug.apk"
echo "RELEASE: app/build/outputs/apk/release/app-release-unsigned.apk"
