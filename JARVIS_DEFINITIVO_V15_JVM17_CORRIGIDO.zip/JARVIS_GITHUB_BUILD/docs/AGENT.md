# JARVIS Agent — V6

O agente une memória e execução local.

Fluxo:
Usuário → Agente → Orquestrador → ActionPlan → ToolExecutor → Android.

A IA externa continua sendo fallback/conversação e, futuramente, poderá
produzir planos estruturados. Ela não recebe acesso arbitrário ao aparelho.

Memória:
- `messages`: histórico de conversa.
- `facts`: fatos que o usuário explicitamente pediu para guardar.

Exemplos:
- `lembrar que ...`
- `minha memória`
