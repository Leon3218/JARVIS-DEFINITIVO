# JARVIS V5 — Roadmap

## Implementado nesta V4
- Núcleo nativo Kotlin.
- Launcher/Home compatível com Android.
- Reconhecimento de voz pt-BR.
- TTS pt-BR.
- Memória SQLite.
- Armazenamento de credenciais via Android Keystore.
- Adaptadores de IA configuráveis.
- Executor de ferramentas local.
- Ações por linguagem natural: bateria, lanterna, câmera, Wi-Fi, Bluetooth,
  configurações, notificações, som/volume, localização, pesquisa, sites,
  abertura de aplicativos instalados e retorno ao launcher.
- Diagnóstico de rede.

## Próximo núcleo
1. Intenções estruturadas (Intent -> parâmetros -> ferramenta).
2. Confirmação para ações sensíveis.
3. Memória semântica e preferências.
4. Conversação contínua.
5. Orquestrador de IA com ferramentas.
6. HUD/launcher avançado.
7. Tarefas e automações permitidas pelo Android.
8. Testes em aparelho real e build release assinado.

## Limites
O JARVIS não deve fingir poderes que um aplicativo comum não possui. Funções
privilegiadas (por exemplo, desligar o aparelho, alterar políticas do sistema,
controlar outras apps sem suas APIs ou substituir o sistema operacional)
dependem de permissões especiais, Device Owner, acessibilidade, root ou de
interfaces oficiais do Android.


## V5 — Orquestrador
- `ActionPlan` para representar intenções de forma estruturada.
- `Orchestrator` para mapear linguagem natural para uma allowlist.
- `ToolExecutor` agora executa planos explícitos.
- Contrato preparado para futura tool-calling da IA.
- Arquitetura documentada para confirmação de ações sensíveis.


## V6 — Agente e memória
- Contexto de agente.
- Memória permanente de fatos.
- Encadeamento agente → orquestrador → executor.
- Histórico de ações executadas.

## V7 — IA e ferramentas
- Contrato AiToolCall.
- Política central de allowlist.
- Parser de fallback.
- Execução segura de chamadas da IA.
- Preparação para tool-calling nativo.

## V8 — Conversação contextual
- AgentContext por mensagem.
- Histórico recente + fatos permanentes enviados ao cérebro de IA.
- Prompt de tool-calling documentado.
- Separação entre conversa e execução local.

## V9 — Voz contínua
- Estado explícito de conversa.
- Controlador de loop de voz.
- Comandos para iniciar/parar conversa contínua.
- Preparação para reiniciar o reconhecimento após TTS.

## V10 — Conversa por voz funcional
- Loop SpeechRecognizer → agente → TTS → SpeechRecognizer.
- Reinício após conclusão do TTS.
- Recuperação de erros transitórios.
- Botão de voz como liga/desliga do modo contínuo.
- Encerramento seguro no ciclo de vida da Activity.

## V11 — HUD / Central Launcher
- Interface reorganizada em estilo central JARVIS.
- Console, indicadores e controles principais.
- Base preparada para páginas HUD modulares.
