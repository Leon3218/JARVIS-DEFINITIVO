# Tool-calling seguro — V7

A IA não acessa o Android diretamente. Ela pode solicitar uma ferramenta;
o aplicativo valida a solicitação e só então executa.

Formato de fallback:
`ACTION:app|ARG:Spotify|CONFIRM:false`

Fluxo:
IA → AiToolCallParser → ToolPolicy → ToolExecutor → Android → resultado.

Ações sensíveis futuras devem exigir confirmação explícita.
O próximo passo é criar adaptadores para o tool-calling nativo dos provedores,
sem acoplar o restante do aplicativo a um fornecedor.
