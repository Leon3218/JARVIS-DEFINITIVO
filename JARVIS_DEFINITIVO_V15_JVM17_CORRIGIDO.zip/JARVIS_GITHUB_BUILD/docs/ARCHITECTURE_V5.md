# JARVIS V5 — Arquitetura do cérebro

```text
Voz / Texto
    ↓
MainActivity
    ↓
Orchestrator
    ↓
ActionPlan (allowlist)
    ↓
ToolExecutor
    ↓
DeviceTools
    ↓
Android
```

Quando a solicitação não corresponde a uma ferramenta local:

```text
Usuário → AIClient → resposta textual
```

A evolução planejada é:

```text
Usuário
  ↓
IA / Orquestrador
  ↓
Plano estruturado
  ↓
Validador de segurança
  ↓
Confirmação (quando necessária)
  ↓
ToolExecutor
  ↓
Resultado real
  ↓
Memória + TTS
```

## Princípio de segurança

A IA não recebe acesso arbitrário ao dispositivo. Ela só pode solicitar ações
que estejam explicitamente registradas na allowlist do aplicativo.

Ações sensíveis futuras deverão marcar `requiresConfirmation=true` e solicitar
confirmação do usuário antes da execução.

## API de IA

Para novas integrações OpenAI, usar a Responses API; a documentação oficial
atual informa que a antiga Assistants API foi encerrada em 26/08/2026.
