# JARVIS V10 — Conversa por voz contínua

O botão **COMANDO DE VOZ** agora alterna o modo de conversa:

1. JARVIS ativa o modo contínuo.
2. SpeechRecognizer escuta em `pt-BR`.
3. O texto passa pelo agente, memória, ferramentas e IA configurável.
4. JARVIS responde com TTS.
5. Quando o TTS termina, o reconhecimento é iniciado novamente.
6. Erros transitórios de reconhecimento não encerram o modo.
7. Pressionar o botão novamente encerra a conversa contínua.

O modo não funciona como um microfone oculto permanente: ele só fica ativo
depois de o usuário acioná-lo e enquanto a Activity estiver em uso.

## Segurança e comportamento

- A permissão de microfone continua sendo obrigatória.
- O reconhecimento é interrompido ao sair da Activity.
- O loop espera o TTS terminar para evitar que JARVIS reconheça a própria voz.
- O modo pode ser encerrado pelo botão ou pelos comandos:
  `parar conversa` / `encerrar conversa`.

## Próxima etapa

Adicionar a interface HUD definitiva e transformar o launcher em uma central
JARVIS com cartões de status, memória, voz, IA, aplicativos e ações rápidas.
