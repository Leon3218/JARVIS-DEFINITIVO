# JARVIS V8 — Conversação contextual

O JARVIS agora prepara um `AgentContext` para cada mensagem.

O contexto contém:
- mensagem atual;
- últimas 12 mensagens;
- até 20 fatos permanentes lembrados.

O contexto é formatado para o cliente de IA, mas a execução de ferramentas
continua separada e protegida pela `ToolPolicy`.

Fluxo:
Usuário → Agente local → contexto → IA (quando necessário)
                    ↘ ferramenta local → resultado

Isso permite conversação contínua sem conceder à IA acesso direto ao Android.
