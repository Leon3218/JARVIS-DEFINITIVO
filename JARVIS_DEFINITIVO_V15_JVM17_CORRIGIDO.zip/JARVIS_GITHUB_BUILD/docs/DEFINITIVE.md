# JARVIS Definitivo V13 (correção de build)

Esta versão consolida a base V12 e corrige a incompatibilidade de tipos entre
`MainActivity` e `AIClient`: o histórico retornado pela memória é uma lista de
strings e o cliente de IA agora aceita esse formato diretamente.

O workflow do GitHub:
1. baixa o repositório;
2. localiza o ZIP;
3. extrai o projeto;
4. encontra a raiz Gradle;
5. configura Java 17;
6. instala Gradle 8.9;
7. compila Debug;
8. compila Release;
9. verifica os APKs;
10. publica os APKs como artifacts.

O APK release continua **não assinado com uma chave privada de produção**.
Para instalação/teste, use o artifact Debug. Para Play Store, a assinatura de
produção deve ser configurada separadamente no GitHub Secrets.
