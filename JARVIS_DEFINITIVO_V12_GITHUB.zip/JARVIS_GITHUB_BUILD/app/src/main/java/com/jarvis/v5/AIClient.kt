package com.jarvis.v5

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors

class AIClient(private val secrets: SecretStore) {
    private val pool = Executors.newCachedThreadPool()

    fun ask(user: String, memory: List<Pair<String, String>>, callback: (String) -> Unit) {
        pool.execute {
            val answer = try { route(user, memory) } catch (e: Exception) {
                "Falha no núcleo de IA: ${e.message ?: "erro desconhecido"}"
            }
            callback(answer)
        }
    }

    private fun route(user: String, memory: List<Pair<String, String>>): String {
        return when (secrets.get("provider")?.lowercase()) {
            "gemini" -> callGemini(user, memory)
            "anthropic" -> callAnthropic(user, memory)
            "openai" -> callOpenAI(user, memory)
            else -> "A IA ainda não foi configurada. O núcleo local está funcionando. Configure um provedor e uma chave para ativar o cérebro online."
        }
    }

    private fun prompt(user: String, memory: List<Pair<String, String>>): String {
        val history = memory.joinToString("\n") { "${it.first}: ${it.second}" }
        return """Você é JARVIS, assistente pessoal em português do Brasil.
Seja objetivo, educado e seguro.
Nunca diga que executou uma ação Android se o aplicativo não confirmou a execução.
Quando uma solicitação puder ser atendida por uma ferramenta local, prefira a ferramenta.
O aplicativo aceita planos explícitos no formato ACTION:<acao>|ARG:<argumento> somente quando isso for implementado pelo orquestrador.
Ações permitidas atualmente: battery, flashlight, camera, settings, wifi, bluetooth,
notifications, sound, location, home, search, url, app.
Quando precisar executar uma ação, responda em uma única linha:
ACTION:<acao>|ARG:<argumento opcional>|CONFIRM:false
Para ações que devam pedir confirmação ao usuário, use CONFIRM:true.
Nunca invente permissões ou capacidades privilegiadas.
Histórico recente:
$history

Usuário: $user""".trimIndent()
    }

    private fun post(url: String, headers: Map<String, String>, body: String): JSONObject {
        val c = URL(url).openConnection() as HttpURLConnection
        c.requestMethod = "POST"
        c.connectTimeout = 30000
        c.readTimeout = 60000
        c.doOutput = true
        c.setRequestProperty("Content-Type", "application/json")
        headers.forEach { (k, v) -> c.setRequestProperty(k, v) }
        c.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
        val stream = if (c.responseCode in 200..299) c.inputStream else c.errorStream
        val text = stream.bufferedReader().use { it.readText() }
        if (c.responseCode !in 200..299) error("HTTP ${c.responseCode}: $text")
        return JSONObject(text)
    }

    private fun callOpenAI(user: String, memory: List<Pair<String, String>>): String {
        val key = secrets.get("api_key") ?: return "Configure sua chave OpenAI."
        val endpoint = secrets.get("endpoint") ?: "https://api.openai.com/v1/responses"
        val model = secrets.get("model") ?: return "Configure o modelo OpenAI nas configurações do JARVIS."
        val input = JSONArray()
        memory.forEach { input.put(JSONObject().put("role", it.first).put("content", it.second)) }
        input.put(JSONObject().put("role", "user").put("content", prompt(user, memory)))
        val body = JSONObject().put("model", model).put("input", input)
        val r = post(endpoint, mapOf("Authorization" to "Bearer $key"), body.toString())
        val output = r.optString("output_text")
        if (output.isNotBlank()) return output
        val out = r.optJSONArray("output") ?: return r.toString()
        for (i in 0 until out.length()) {
            val item = out.optJSONObject(i) ?: continue
            val content = item.optJSONArray("content") ?: continue
            for (j in 0 until content.length()) {
                val text = content.optJSONObject(j)?.optString("text")
                if (!text.isNullOrBlank()) return text
            }
        }
        return r.toString()
    }

    private fun callGemini(user: String, memory: List<Pair<String, String>>): String {
        val key = secrets.get("api_key") ?: return "Configure sua chave Gemini."
        val model = secrets.get("model") ?: return "Configure o modelo Gemini nas configurações do JARVIS."
        val endpoint = "https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent?key=$key"
        val r = post(endpoint, emptyMap(), JSONObject().put("contents", JSONArray().put(JSONObject().put("parts", JSONArray().put(JSONObject().put("text", prompt(user, memory)))))).toString())
        return r.optJSONArray("candidates")?.optJSONObject(0)?.optJSONObject("content")?.optJSONArray("parts")?.optJSONObject(0)?.optString("text") ?: r.toString()
    }

    private fun callAnthropic(user: String, memory: List<Pair<String, String>>): String {
        val key = secrets.get("api_key") ?: return "Configure sua chave Anthropic."
        val model = secrets.get("model") ?: return "Configure o modelo Anthropic nas configurações do JARVIS."
        val r = post("https://api.anthropic.com/v1/messages", mapOf("x-api-key" to key, "anthropic-version" to "2023-06-01"), JSONObject().put("model", model).put("max_tokens", 1200).put("messages", JSONArray().put(JSONObject().put("role", "user").put("content", prompt(user, memory)))).toString())
        return r.optJSONArray("content")?.optJSONObject(0)?.optString("text") ?: r.toString()
    }
    fun buildAgentPrompt(context: AgentContext): String {
        return ConversationContext.asPrompt(context)
    }

}
