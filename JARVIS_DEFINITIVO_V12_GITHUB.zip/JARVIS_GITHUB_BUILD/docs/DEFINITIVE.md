# JARVIS DEFINITIVO — V12

## Arquitetura final desta etapa

Interface HUD
→ entrada por texto/voz
→ JarvisAgent
→ memória/contexto
→ Orchestrator / AI Tool Parser
→ ToolPolicy
→ ToolExecutor
→ Android

Quando não há ação local, o agente envia o contexto para o provedor de IA
configurado. A resposta pode ser texto normal ou um tool call explícito.

## Limites reais do Android

O JARVIS pode controlar somente APIs e intents que o Android disponibiliza
ao aplicativo e para as quais existam permissões adequadas. Ele não substitui
o sistema operacional, não obtém privilégios root automaticamente e não pode
ligar/desligar fisicamente o aparelho por comando comum.

O modo launcher usa o HOME intent e a Activity está registrada como candidata
a launcher. O usuário precisa escolhê-la como aplicativo inicial nas
configurações do Android.

## APK

O workflow gera:
1. `app-debug.apk`: assinado com a chave de debug do Android e destinado a
   teste/instalação no aparelho.
2. `app-release-unsigned.apk`: variante release sem assinatura privada.

A assinatura Play Store será adicionada depois, usando GitHub Secrets, sem
expor o keystore no repositório.
